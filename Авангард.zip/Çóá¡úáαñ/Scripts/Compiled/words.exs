﻿
1я скорость должна быть меньше 2й.
2я скорость должна быть меньше 3й.
3я скорость должна быть меньше 4й.
Переход с 2й скорости на 1ю должен быть меньше перехода с 3й на 2ю.
Переход с 3й скорости на 2ю должен быть меньше перехода с 4й на 3ю.
Ошибка
SELECT rd.`idRecipe`, mt.kod, mt.`name`, dozp.`Name`,rd.prc,rd.otkl_plus, rd.otkl_minus, rd.idmat, rd.idDozP, rd.npp, rd.seq, mt.plotn 
FROM 
recipedet rd 
left join 
materials mt on rd.IdMat=mt.id 
left join 
doz_points dozp on rd.iddozp=dozp.id where rd.IdRecipe=
 order by IdDozP,seq
SELECT gpdet.IdGp, mt.kod, mt.`Name`, dp.`name` dpName, gpdet.prc, gpdet.otkl_plus, gpdet.otkl_minus, 
gpdet.IdMat, gpdet.idDozP, gpdet.npp, gpdet.seq 
FROM 
`gpdet` left join 
`materials` mt on gpdet.IdMat=mt.id 
left join 
doz_points dp on gpdet.idDozP=dp.id where gpdet.IdGp=
 order by IdDozP,seq;



select round(sum(prc),3) summa from 
`recipedet` where `IdRecipe`=
;
select round(sum(prc),3) summa from 
`gpdet` where `IdGp`=
;
select round(sum(prc),3) summa from 
`ppdet` where `IdPp`=
;

0
 where `doz`=0
1
 where `doz` in (1,7)
2
 where `doz` in (2,7)
3
 where `doz` in (3,4,5,6)
 or `id`='
'
select * from 
`materials`
 order by `doz`, `name`

11111100

SELECT b.`id`, b.`idM`, b.`blockIn`, m.`Name` MatName, m.`kod`, b.`ves` 
FROM 
`bunkers` b left join 
`materials` m on b.idm=m.`id`
where b.`id` between 100 and 199 order by b.`id`
SELECT b.`id`, b.`idM`, b.`blockIn`, m.`Name` MatName, m.`kod`, b.`ves` 
FROM 
`bunkers` b left join 
`materials` m on b.idm=m.`id`
where b.`id` between 200 and 299 order by b.`id`
li
ll
li
ll
LoadList1_
li
ll
li
ll
li
ll
cbNameK
lbText
cbNameK
IdMatBunk
IdMatBunk
LoadList1_1
lbText
lbText
li
ll
li
ll
LoadList2_
li
ll
li
ll
li
ll
cbNameD
lbText
cbNameD
IdMatBunk
IdMatBunk
LoadList2_1
lbText
lbText

Загрузка в бункер 
. 
Очередь: 
LoadList1_
, 
LoadList1_
Режим загрузки сырья из завальной ямы зерна останавливается
Режим загрузки сырья из завальной ямы зерна не запущен

Загрузка в бункер 
. 
Очередь: 
LoadList2_
, 
LoadList2_
Режим загрузки добавок останавливается
Режим загрузки добавок не запущен



 where 
`name` like '%
%' 
and 
`kod` like '%
%' 

select doz_p.`id`, doz_p.`name`, doz_p.`MaxVes`, 
ifNull((select round(sum(prc),3)*(select gp.ves  from 
`gp` where gp.id='
')/100 
from 
`gpdet` gd where gd.idGp='
' and gd.idDozP=doz_p.id),0) SumVes 
from 
`doz_points` doz_p order by `id`;
select doz_p.`id`, doz_p.`name`, doz_p.`MaxVes`, 
ifNull((select round(sum(prc),3)*(select pp.VesPort  from 
`pp` where pp.id='
')/100 
from 
`ppdet` pd where pd.idPp='
' and pd.idDozP=doz_p.id),0) SumVes 
from 
`doz_points` doz_p order by `id`;

SELECT mt.kod, mt.`name`, dp.`name`, ppd.idBunk, ppd.prc, 
round((select pp.VesPort from 
`pp` where pp.id='
')*ppd.prc/100,2) ves, 
ppd.otkl_plus, ppd.otkl_minus, ppd.IdMat, ppd.idDozP, ppd.seq, ppd.npp 
FROM 
`ppdet` ppd left join 
`materials` mt on ppd.IdMat=mt.`id` 
left join 
`doz_points` dp on ppd.idDozP=dp.`id` 
where ppd.idPP='
' 
order by ppd.idDozP, ppd.seq;
select `idSilos` from 
`ppvigr` where `idPP`=
 order by seq
select `bunkers`.`id` from 
`bunkers` 
where IdDozP='
' and 
idM='
' and blockOut=0 order by `id`
_
Авария
Открыто
Закрыто
<-- - -->
MehSt
ShiberStateError
ShiberStateOpen
ShiberStateClose
Line_
Вправо
Влево
<--->
predMehSt
predSSE
ShiberStateError
predSSO
ShiberStateOpen
predSSC
ShiberStateClose


ч 
ч 
м 
с

2х поточник 10210
Шибер 10610
Шибер 10620
Шибер 10630
Шибер 10640
Шибер 10710
Шибер 10720
Шибер 10730
Шибер 10740
Шибер 21310
Шибер 21320
Шибер 21330
Шибер 40210
Шибер 40220
Шибер 41110
Шибер 41210
Шибер 42210
Шибер 50210
Шибер 50220
Шибер 50230
Шибер 50310
Шибер 50320
Шибер 50330
Шибер 50340
Шибер 50410
Шибер 50420
Шибер 50430
Шибер 50440
Шибер 50510
Шибер 50520
Шибер 50530
Шибер 50540
Шибер 50701
Шибер 50702
Шибер 50703
Шибер 50704
Шибер 50705
Шибер 50706
Шибер 50707
Шибер 50708
Шибер 50709
Шибер 50710
Шибер 50711
Шибер 50712
Шибер 50713
Шибер 50714
Шибер 50715
Нория 10200
Нория 10400
Нория 21200
Нория 20300
Нория 30500
Нория 40100
Нория 40800
Нория 41500
Нория 42500
Нория 50100
Конвейер 10110
Конвейер 10500
Конвейер 10600
Конвейер 10700
Конвейер 20110
Конвейер 21300
Конвейер 21500
Конвейер 30340
Конвейер 30400
Конвейер 30700
Конвейер 40200
Конвейер 40400
Конвейер 40700
Конвейер 41100
Конвейер 50200
Конвейер 50300
Конвейер 50400
Конвейер 50500
Лок.фильтр завальной ямы 21100
Лок.фильтр нории 21200
Лок.фильтр нории 30500
Лок.фильтр нории 40100
Лок.фильтр нории 40800
Лок.фильтр нории 41500
Лок.фильтр нории 42500
Лок.фильтр конвейера 30400
Лок.фильтр конвейера 41100
Лок.фильтр конвейера 40200
Аспирация 51100
Шлюз аспирации 51100
Скальператор
Питатель дробилки
Дробилка
Дробилка при вращении вправо
Дробилка при вращении влево
Фильтр дробилки
Шлюз 30350
Вибратор на малых весах
Смеситель
Насос 2/25 УДЖК-1-БП
Насос 8/25 УДЖК-1-БП
Насос 5/25 УДЖК-1
Насос 8/25 УДЖК-1
Пресс-гранулятор
Кондиционер пресс-гранулятора
Двигатель пресс-гранулятора
Аспирация охладителя гранул
Шлюз аспирации охладителя гранул
Шлюз охладителя гранул
Измельчитель гранул
Питатель измельчителя гранул
Двигатель 1 просеивателя
Двигатель 2 просеивателя
Смеситель установки покрытия гранул жиром
Насос установки покрытия гранул жиром
3х ходовой клапан установки покрытия гранул жиром
Форсунка установки покрытия гранул жиром
Смеситель мелассы
Насос мелассы
Питатель мелассы
Дозатор 101
Дозатор 102
Дозатор 103
Дозатор 104
Дозатор 105
Дозатор 106
Дозатор 107
Дозатор 108
Дозатор 109
Дозатор 110
Дозатор 201
Дозатор 202
Дозатор 203
Дозатор 204
Дозатор 301
Дозатор 302
Дозатор 303
Дозатор 304
Дозатор 305
Дозатор 306
Дозатор 307
Дозатор 308
Дозатор 309
Дозатор 310
Дозатор 311
Дозатор 312
несуществующий механизм №144
несуществующий механизм №145
несуществующий механизм №146
несуществующий механизм №147



MHAlarm_
MHEmerg_
TO_
SMh_
SMh_
MH_
 - пропущено ТО!
 пропущено ТО!
 - приближается ТО!
 приближается ТО.
Ошибка SQL

eee
загружено в бункер 
используется в программе производства "
"
используется в готовой продукции "
"
используется в рецепте "
"
Удаление материала
Удалить 
 ?
Ошибка
Не возможно удалить сырьё, т.к. оно

792
PRG

Программист
rights
UserName
iduser
Ошибка авторизации
Пароль не опознан

Name
id
id
Name
MaxVes
Name
MaxVes
VesBunk
Id
ves
Переменная "
" не найдена
IdMatBunk
Id
IdM
Переменная "
" не найдена
VesBunk
Id
ves
Переменная "
" не найдена
IdGPBunk
Id
IdGP
Переменная "
" не найдена
ObBunk
VesBunk
Не задан объем бункера
В бункере "
" не назначен материал
Переменная "ObBunk
" не найдена
ObBunk
VesBunk
Не задан объем бункера
В бункере "
" не назначен продукт
Переменная "ObBunk
" не найдена
id
lbText
blockIn
idM
 
 - 
MatName
 
 - пустой
 (блок)
id
lbText
blockIn
idM
 
 - 
MatName
 
 - пустой
 (блок)


select silos.`id`, ifnull(`idGp`,0) idGp,`V`, 
ifnull(`BlockIn`,0) BIn, ifNull(`BlockOut`,0) BOut, silos.`ves`, 
ifnull(gp.`Name`,'') nname, ifnull(gp.`kod`,'') nkod, 
if(IfNull(idGp,0)=0 and exists(select * from 
`ppvigr` 
where `ppvigr`.`idpp`<>'
' and idSilos=silos.`id`),1,0) used 
from 
`silos` left join 
`gp` on silos.idGp=gp.`id` order by `id`;

cbNameU_
 - 
nname
 : 
nkod
 (другой продукт)
BIn
 (заблокирован)
used
 (исп. в другой ПП)

insert into 
`ppvigr` (`IdPP`, `IdSilos`, `Seq`) value (
, 
, 
);
select * from 
`recipedet` where idRecipe=
Ошибка
Рецепт с таким именем и кодом уже существует.
INSERT INTO 
`recipes` (`RecipName`, `kod`)
VALUES (
, 
);
select max(id) from 
materials
Ошибка
Рецепт с таким именем и кодом уже существует.
UPDATE 
`recipes` set `RecipName`='
', 
`kod`='
' where `id`='
';
select max(id) from 
recipes
insert into 
recipedet 
SELECT 
 `idN`, npp, idMat, seq,prc,otkl_minus,otkl_plus, IdDozP 
FROM 
recipedet rd where rd.idrecipe=
;
insert into 
`gpdet` (IdGp, npp, seq, IdMat, prc, otkl_minus, otkl_plus, idDozP) 
(SELECT gp.id IdGp, 
'
' npp, 
(select ifnull(max(seq),0)+1 from 
`gpdet` gd where gd.IdGp=gp.id and gd.idDozP='
') seq, 
'
' idMat, 
'
' prc, 
'
' otkl_minus, 
'
' otkl_plus, 
'
' IdDozP 
FROM gp where gp.idRecipe='
');
select ifnull(max(seq),0)+1 from 
`recipedet` where IdRecipe='
' and IdDozP='
';
INSERT INTO 
`recipedet`(`IdRecipe`,`npp`,`IdMat`,`IdDozP`,`seq`,`prc`,`otkl_minus`,`otkl_plus`)
VALUES (
, 
, 
, 
, 
, 
, 
, 
);
UPDATE 
`gp` SET 
`kod` = 
, 
`Name` = 
, 
`typ` = 
, 
`ver` = 
, 
`ves` = 
, 
`time_suh` = 
, 
`time_mok` = 
, 
`speedmel` = 
, 
`plotn` = 
 
WHERE `id` = 
;
Нельзя изменить выбранный продукт.
Продукт загружен в бункер готовой продукции
delete from 
`gpdet` where IdGp=
delete from 
`gp` where Id=
Нельзя удалить выбранный продукт.
Продукт загружен в бункер готовой продукции
П

INSERT INTO 
`gp` 
(`id`,`kod`,`Name`,`typ`,`ver`,`ves`,`time_suh`,`time_mok`,`speedmel`,`plotn`,`idRecipe`) 
VALUES (
,
,
,
,
,
,
,
,
,
,
);
INSERT INTO 
`gpdet` (`IdGp`,`npp`,`seq`,`IdMat`,`prc`,`otkl_minus`,`otkl_plus`,`idDozP`) 
VALUES (
,
,
,
,
,
,
,
);
Исходный рецепт не найден.
delete from 
`gpdet` where `idgp`='
';
insert into 
`gpdet` (idGP, npp, seq, idMat, prc, otkl_minus, otkl_plus, idDozP) 
select '
' idGP, npp, seq, idMat, prc, otkl_minus, otkl_plus, idDozP 
from 
`recipedet` rd where rd.IdRecipe='
';
update 
`gp` set plotn=
(select round(100/sum(gpdet.prc/if(ifnull(mt.plotn,0)=0,1000,mt.plotn)),0) pl 
from 
`gpdet` left join 
`materials` mt on gpdet.IdMat=mt.`id` 
where gpdet.idGP='
') 
where gp.`id`='
';
select round(100/sum(gpdet.prc/if(ifnull(mt.plotn,0)=0,1000,mt.plotn)),0) pl 
from 
`gpdet` left join 
`materials` mt on gpdet.IdMat=mt.`id` 
where gpdet.idGP='
';
INSERT INTO 
`pp` (`id`,`kod`,`Name`,`typ`,`time_suh`,`time_mokr`,`speedmel`,
`VesPart`, `VesPort`, `PortKol`, `PortCompl`, `Compl`, `idGP`, dtCreate, npp) 
VALUES (
, 
, 
, 
, 
, 
, 
, 
, 
, 
, 
0
, 
0
, 
, 
, 
);
insert into ppdet 
select '
' as IdPP, npp, idmat, seq, otkl_minus, otkl_plus, prc, idDozP, 
ifnull((select min(`id`) from 
`bunkers` 
where `bunkers`.idM=idMat and `bunkers`.idDozP=gpdet.idDozP and `bunkers`.blockOut=0),0) IdBunk 
from 
`gpdet` where gpdet.idgp='
';
%
speed4
speed3
speed2
speed1
sw43
sw32
sw21
stolb
name
Id
select kod, doz from 
`materials` where `id`='
';
select `id`, count(`id`) CouId from 
`materials` where `kod`='
';
-1
Ошибка
В рецепте уже есть компонент с таким кодом и местом дозирования.
select ifnull(max(npp),0)+1 from 
`recipedet` where IdRecipe=
Ошибка
Выберите компонент.
Ошибка
Выберите рецепт.
Предупреждение
Сначала выберите компонент для редактирования
Ошибка
В рецепте уже есть компонент с таким кодом и местом дозирования.
UPDATE 
`recipedet`
SET `seq` = 
(select ifnull(max(seq),0)+1 ms from recipedet 
where idRecipe='
' and idDozP='
') 
WHERE `IdRecipe` = '
' 
 AND `npp` = '
';
UPDATE 
`recipedet`
SET `seq` = `seq`-1 
WHERE `IdRecipe` = '
' 
 AND `idDozP` = '
' 
 and `seq`> '
';
UPDATE 
`recipedet`
SET `IdMat` = '
', 
`IdDozP` = '
', 
`prc` = '
', 
`otkl_minus` = '
', 
`otkl_plus` = '
' 
WHERE `IdRecipe` = '
' 
 AND `npp` = '
';
UPDATE 
`gpdet` SET `IdMat` = '
', `IdDozP` = '
', `prc` = '
', 
`otkl_minus` ='
', `otkl_plus` = '
' 
 WHERE `IdGp` in (select gp.id from 
`gp` where gp.idrecipe='
') 
AND `npp` = '
';
Предупреждение
Сначала выберите компонент для удаления.
Предупреждение
Сначала выберите рецепт, потом компонент для удаления.
delete from 
`recipedet` 
where `IdRecipe`=
 and `npp`=
;
delete from 
`gpdet` 
 WHERE `IdGp` in (select gp.id from 
`gp` where gp.idrecipe='
') 
AND `npp` = '
';

SELECT `id`, `Name`, `kod` FROM 
materials order by Name,doz
Ошибка
Выберите рецепт
SELECT count(*) FROM 
`recipes` where `RecipName`=
 and `kod`=

Ошибка
Выберите рецепт для копирования
INSERT INTO 
`recipes` (`RecipName`, `kod`)
VALUES (
, 
);
SELECT count(*) FROM recipes where RecipName ='
' and 
kod='
' and `id`<>'
';
delete from recipes where Id=
select * from 
recipedet where idRecipe=
0%
where 
`recipname` like '%
%' 
and 
`kod` like '%
%' 


Создание нового продукта
Выберите рецепт, на основе которого хотите создать продукт.
Нажмите на кнопку "Добавить продукт".
select count(idGp) ccc from 
`silos` where idGp=
Ошибка
Выберите продукт для изменения.
select count(idGp) ccc from 
`silos` where idGp=
UPDATE 
`gpdet` SET 
`otkl_minus` = 
, 
`otkl_plus` = 
, 
`idDozP` = 
, 
`seq` = (select * from (select ifnull(max(seq),0)+1 ms from 
`gpdet`
where idGp='
' and idDozP='
') as err1093)
WHERE `IdGP` = '
' AND `npp` = '
';
UPDATE 
`gpdet`
SET `seq` = `seq`-1 
WHERE `IdGp` = '
'
 AND `idDozP` = '
' 
 and `seq`> '
';
UPDATE 
`gpdet` SET 
`otkl_minus` = 
, 
`otkl_plus` = 
, 
`idDozP` = 
 
WHERE `IdGp` = 
 AND `npp` = 
;
Ошибка
Не выбрано сырьё
 where 
`name` like '%
%' 
and 
`kod` like '%
%' 

100%
Ошибка
Рецепт должен содержать 100%
SELECT ifnull(max(id),0)+1 NextId FROM 
`gp`;
Ошибка
Выберите рецепт


select count(id), ifnull(`id`,0) id from 
`recipes` where `id`='
';
Выберите ГП для обновления.

  Код:
  вер.
  тип: 
  
%

Ошибка
Продукт заполнен на 
%. Должно быть ровно 100%
 Код:
 Вер:
 Тип:
 - 

/
Ошибка
Выбранный бункер задействован для выгрузки в программе производства другого продукта
select ifnull(max(`id`)+1,1) fld1, '1' fld2 from 
`pp` union 
select ifnull(max(npp)+1,1) fld1, '2' fld2 from 
`pp` where `compl`=0;
update 
`pp` set 
`kod`='
', 
`Name`='
', 
`typ`='
', 
`time_suh`='
', 
`time_mokr`='
', 
`speedmel`='
', 
`VesPart`='
', 
`VesPort`='
', 
`PortKol`='
', 
`idGP`='
' 
where `id`='
';
delete from 
`ppdet` where idPP='
';
 Код:
 Вер:
 Тип:
Выберите ПП
0
0
UPDATE 
`ppdet` SET 
`otkl_minus` = 
, 
`otkl_plus` = 
, 
`idDozP` = 
, 
`seq` = (select * from (select ifnull(max(seq),0)+1 ms from 
`gpdet`
where idPP='
' and idDozP='
') as err1093), 
`idBunk` = 
 
WHERE `IdPp` = '
' AND `npp` = '
';
UPDATE 
`ppdet`
SET `seq` = `seq`-1 
WHERE `IdPp` = '
'
 AND `idDozP` = '
' 
 and `seq`> '
';
UPDATE 
`ppdet` SET 
`otkl_minus` = 
, 
`otkl_plus` = 
, 
`idBunk` = 
 
WHERE `IdPp` = '
' AND `npp` = '
';
Ошибка
Не выбрано сырьё
0
При проверке выбора бункера в tblPPDet не нашли ячейку
Предупреждение!
Не выберан бункер готовой продукции.
1
1
Предупреждение!
Не выберан бункер готовой продукции.
IdGPBunk
Ошибка
Переменная "
" не найдена
Переменная "
" не найдена в BtnSilosEdit_OnClick
1
0
1
0
, `ves`=

0
0



, `ves`='0' 
update 
`silos` set `idGp`=
, 
`blockIn`=
, 
`blockOut`=
 
where `id`=
1
0
1
0
0
1
1
0
IdMatBunk
Переменная "
" не найдена в BtnSBEdit_OnClick
, `ves`=

0
0
0
0
IdMatBunk
Переменная "
" не найдена в BtnSBEdit_OnClick
, `ves`='0'
update 
`bunkers` set `idM`=
, 
`Speed4`=
, 
`Speed3`=
, 
`Speed2`=
, 
`Speed1`=
, 
`SW43`=
, 
`SW32`=
, 
`SW21`=
, 
`Stolb`=
, 
`HandStolb`=
, 
`Cleared`=
, 
`blockIn`=
, 
`blockOut`=
 
where `id`=
select `id`, count(`id`) CouId from 
`materials` where `kod`='
';
select kod, doz, speed4, speed3, speed2, speed1, sw43, sw32, sw21, stolb from 
`materials` where `id`=
SELECT `id`, `Name`, `kod` FROM 
`materials` where (`load`=0) or (`id`=
) order by `Name`
SELECT `id`, `Name`, `kod` FROM 
`materials` where (`load`=1) or (`id`=
) order by `Name`
IdMatBunk


cbNameK

select use_clear from 
materials where `id`=
cbNameD

LoadList1_
LoadList1_
LoadList2_
Load
St
Load
St
LoadList1_

LoadList2_

Load
St
Ошибка
Введите величину для корректировки веса!
Ошибка
Выберите бункер для корректировки веса!
VesBunk
LoadList1_
LoadList2_

Ошибка!
Введите наименование сырья.
Ошибка!
Введите 4х значный код сырья.
Ошибка!
Сырьё с наименованием: "
" уже введено в БД.
Ошибка!
Код: 
 уже присвоен сырью "
"
Ошибка!
Введите плотность сырья.
Ошибка!
Введите допустимое отклонение +.
Ошибка!
Введите допустимое отклонение -.
Ошибка
Место загрузки не соответствует месту дозирования.
INSERT INTO 
`materials`(`Name`,`kod`,`load`,`doz`,`plotn`,`otkl_minus`,`otkl_plus`,`use_clear`,
`speed4`,`speed3`,`speed2`,`speed1`,`sw43`,`sw32`,`sw21`,`stolb`) VALUES(
, 
, 
, 
, 
, 
, 
, 
, 
, 
, 
, 
, 
, 
, 
, 
);
Ошибка!
 Выберите сырьевой материал который требуется отредактировать.

Ошибка!
Введите наименование сырья.
Ошибка!
Введите 4х значный код сырья.
Ошибка!
Сырьё с наименованием: "
" уже введено в БД.
Ошибка!
Код: 
 уже присвоен сырью "
"
Ошибка!
Введите плотность сырья.
Ошибка!
Введите допустимое отклонение +.
Ошибка!
Введите допустимое отклонение -.
Ошибка
Место загрузки не соответствует месту дозирования.
UPDATE 
`materials` SET 
`Name` = 
, 
`kod` = 
, 
`load` = 
, 
`doz` = 
, 
`plotn` = 
, 
`otkl_minus` = 
, 
`otkl_plus` = 
, 
`use_clear` = 
, 
`speed4` = 
, 
`speed3` = 
, 
`speed2` = 
, 
`speed1` = 
, 
`sw43` = 
, 
`sw32` = 
, 
`sw21` = 
, 
`stolb` = 
 WHERE `id` =
;
Ошибка!
Выберите сырьевой материал который требуется удалить из базы данных.
SELECT id , 1 as eee, bunkers.`name` nnn FROM 
bunkers where idm=
 union 
SELECT idpp id, 2 as eee, pp.`name` nnn FROM 
ppdet,
pp where pp.id=ppdet.idpp and idMat=
 union 
SELECT idgp id, 3 as eee, gp.`name` nnn FROM 
gpdet,
gp where gpdet.IdGp=gp.id and idMat=
 union 
SELECT IdRecipe id, 4 as eee, recipes.`recipname` nnn FROM 
recipedet,
recipes where recipedet.idRecipe=recipes.id and idMat=
;
update 
`recipedet` 
set seq=if(npp=
,
,
) where `IdRecipe`=
 and (npp in (
,
));
update 
`GPDet` 
set seq=if(npp=
,
,
) where `IdGP`=
 and (npp in (
,
));
update 
`PPDet` 
set seq=if(npp=
,
,
) where `IdPP`=
 and (npp in (
,
));
update 
`PP` 
set npp=if(`id`=
,
,
) 
where `id` in (
,
);
update 
`recipedet` 
set seq=if(npp=
,
,
) where `IdRecipe`=
 and (npp in (
,
));
update 
`GPDet` 
set seq=if(npp=
,
,
) where `IdGP`=
 and (npp in (
,
));
update 
`PPDet` 
set seq=if(npp=
,
,
) where `IdPP`=
 and (npp in (
,
));
update 
`PP` 
set npp=if(`id`=
,
,
) 
where `id` in (
,
);
cbNameK
LoadList1_
cbNameK
LoadList1_
LoadList1_

LoadList2_
LoadList2_

select * from 
`users` where pass='
'


select * from 
`type_prod` order by id
select * from 
`doz_points` order by id
select * from 
`bunkers`
select * from 
`silos`

LoadList1_
LoadList2_
Не нажата кнопка "ПУСК" на шкафу управления
Нажат аварийный стоп

на шкафу управления
на завальной яме
на дробилке
на бункерах
на грануляторе 
Старт
Старт
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
ViewMH_
Mh_
ViewAMH_
aMh_
DELETE FROM 
`materials` WHERE `id`=
update 
`silos` set `ves`='
' where id =
;
select round(ifnull(ifnull(s.ves,0)/ifnull(gp.plotn,0)*1000,0),0) ob, 
s.id, ifnull(s.ves,0) ves, ifnull(s.idGp,0) idGp, ifnull(gp.plotn,0) pl 
from 
`silos` s left join 
`gp` on s.idGp=gp.id where s.id='
';
update 
`bunkers` set `ves`='
' where id =
;
select round(ifnull(ifnull(b.ves,0)/ifnull(mt.plotn,0)*1000,0),0) ob, 
b.id, ifnull(b.ves,0) ves, b.idM, ifnull(mt.plotn,0) pl 
from 
`bunkers` b left join 
`materials` mt on b.idm=mt.id where b.id='
';
Из переменной "
" не удалось выделить номер бункера
1111111111111110
0000000000000111
fHand
Не найдена переменная "
"
update 
`pp` set npp=npp-1 where npp>'
';
delete from 
`pp` where id='
';
Сначала деактивируйте программу производства.
Нельзя удалить запущенную программу производства.
delete from 
`ppdet` where idPP='
';
Выберите ПП

cbNameU_
Подождите
cbNameU_
select `idSilos` from 
`ppvigr` where `idPP`=
 order by seq

Не выбрано место дозирования для компонента "
"
Превышение максимального веса для весов "
"
100%
Рецепт должен быть заполнен на 100%
Не допустимый вес порции
Пустая программа производства
Не выбран бункер готовой продукции для выгрузки
Ошибка активации ПП
Программа производства
 программу производства



delete from 
`ppvigr` where idPP='
';

0
update 
`pp` 
set npp=if(`id`='
','
', `npp`+1) 
where `npp` between 
 and 
;
update 
`pp` set `State`='1' where 
`id`='
';

update 
`pp` set `State`='
' where 
`id`='
';
